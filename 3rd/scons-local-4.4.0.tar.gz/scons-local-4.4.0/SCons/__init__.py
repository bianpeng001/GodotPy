__version__="4.4.0"
__copyright__="Copyright (c) 2001 - 2022 The SCons Foundation"
__developer__="bdbaddog"
__date__="Tue, 01 Nov 2022 14:22:18 -0400"
__buildsys__="M1DOG2021"
__revision__="e353c45d68cf4144d396a66ecef58be064ef439f"
__build__="e353c45d68cf4144d396a66ecef58be064ef439f"
# make sure compatibility is always in place
import SCons.compat # noqa